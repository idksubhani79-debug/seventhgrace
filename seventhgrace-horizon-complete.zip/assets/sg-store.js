/* Seventh Grace custom storefront. Prices/totals/stock always come from Shopify. */
(() => {
  'use strict';
  const configNode = document.getElementById('sg-config');
  if (!configNode || window.SGStore) return;
  const config = JSON.parse(configNode.textContent);
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const endpoint = url => url.replace(/\/$/, '') + '.js';
  let cart = null, queue = Promise.resolve(), modal = null, opener = null, quickProduct = null, quickTrigger = null, searchAbort, searchTimer;
  const savedKey = 'seventhgrace:saved:v2';
  let saved;
  try { const value = JSON.parse(localStorage.getItem(savedKey) || '[]'); saved = new Set(Array.isArray(value) ? value.filter(v => typeof v === 'string') : []); } catch { saved = new Set(); }
  const money = (value, currency = cart?.currency || config.currency) => new Intl.NumberFormat(config.locale || 'en', { style: 'currency', currency }).format(value / 100);
  const message = (text, error = false) => {
    const node = $('#toast-message'); if (node) node.textContent = text;
    $('#toast-notification')?.classList.add('active');
    clearTimeout(message.timer); message.timer = setTimeout(() => $('#toast-notification')?.classList.remove('active'), 4500);
    const status = $('#sg-status'); if (status) status.textContent = text;
    if (error) { const box = $('#sg-cart-error'); if (box) { box.textContent = text; box.hidden = false; } }
  };
  const json = async (url, options) => {
    const response = await fetch(url, options); const data = await response.json();
    if (!response.ok || data.status >= 400 || data.errors) throw new Error(typeof data.description === 'string' ? data.description : typeof data.errors === 'string' ? data.errors : data.message || 'Shopify could not complete this request. Please try again.');
    return data;
  };
  const focusables = element => $$('a[href],button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea,[tabindex="0"]', element).filter(el => el.getClientRects().length);
  function closeModal(restore = true) {
    if (!modal) return;
    const old = modal; modal = null; old.classList.remove('active'); old.setAttribute('aria-hidden', 'true'); old.inert = true;
    if (old.id === 'cart-drawer') $('#cart-drawer-overlay')?.classList.remove('active');
    if (old.id === 'mobile-drawer') $('#mobile-drawer-overlay')?.classList.remove('active');
    document.body.classList.remove('no-scroll');
    if (restore && opener?.isConnected) opener.focus();
  }
  function openModal(id, source) {
    const element = document.getElementById(id); if (!element) return;
    const previousOpener = opener; const sourceWasInside = modal?.contains(source); closeModal(false); opener = sourceWasInside ? previousOpener : source || document.activeElement; modal = element;
    element.inert = false; element.setAttribute('role', 'dialog'); element.setAttribute('aria-modal', 'true'); element.setAttribute('aria-hidden', 'false');
    if (!element.getAttribute('aria-label')) element.setAttribute('aria-label', ({'size-guide-modal':'Size guide','quick-view-modal':'Product options','search-modal':'Search','mobile-drawer':'Navigation'})[id] || 'Shopping bag');
    element.classList.add('active'); document.body.classList.add('no-scroll');
    if (id === 'cart-drawer') $('#cart-drawer-overlay')?.classList.add('active');
    if (id === 'mobile-drawer') $('#mobile-drawer-overlay')?.classList.add('active');
    requestAnimationFrame(() => (id === 'search-modal' ? $('#search-input') : focusables(element)[0])?.focus());
  }
  function applyCart(html, state) {
    const doc = new DOMParser().parseFromString(html, 'text/html'); const content = $('.sg-cart-render', doc);
    if (!content) throw new Error('Cart added, but the drawer could not refresh. Open the full bag to check your items.');
    const activeKey = document.activeElement?.dataset.key; const activeDelta = document.activeElement?.dataset.cartDelta;
    for (const host of $$('#sg-cart-content, #sg-cart-page-content')) host.innerHTML = content.outerHTML;
    cart = state;
    if ($('#cart-badge')) $('#cart-badge').textContent = state.item_count;
    if ($('#cart-items-count-text')) $('#cart-items-count-text').textContent = `${state.item_count} ${state.item_count === 1 ? 'Item' : 'Items'}`;
    if (activeKey && modal?.id === 'cart-drawer') {
      const next = $$('[data-key][data-cart-delta]', modal).find(el => el.dataset.key === activeKey && el.dataset.cartDelta === activeDelta);
      (next || $('#cart-close-btn'))?.focus();
    }
  }
  async function refreshCart(sections) {
    const [state, html] = await Promise.all([
      json(endpoint(config.cart)),
      sections?.['sg-cart'] ? Promise.resolve(sections['sg-cart']) : fetch(`${config.cart}?section_id=sg-cart`).then(r => { if (!r.ok) throw new Error('Unable to refresh your bag.'); return r.text(); })
    ]);
    applyCart(html, state);
    return state;
  }
  function mutate(task) {
    queue = queue.catch(() => {}).then(async () => {
      if ($('#sg-cart-error')) $('#sg-cart-error').hidden = true;
      const controls = $$('[data-cart-delta],[data-cart-remove]'); controls.forEach(el => { el.disabled = true; });
      try { return await task(); } finally { controls.forEach(el => { if (el.isConnected) el.disabled = false; }); }
    });
    return queue;
  }
  async function add(form, source) {
    const submit = $('button[type="submit"]', form); const error = $('.sg-form-error', form); if (error) error.hidden = true;
    if (submit?.disabled || submit?.getAttribute('aria-busy') === 'true') return;
    submit?.setAttribute('aria-busy', 'true');
    try {
      await mutate(async () => {
        const body = new FormData(form); body.append('sections', 'sg-cart'); body.append('sections_url', location.pathname);
        const data = await json(endpoint(config.add), { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' }, body });
        // Never retry a successful add if a later refresh fails: that would
        // accidentally add duplicate units to the real Shopify cart.
        await refreshCart(data.sections); openModal('cart-drawer', source); message('Added to your bag.');
      });
    } catch (e) { if (error) { error.textContent = e.message; error.hidden = false; } message(e.message, true); }
    finally { submit?.removeAttribute('aria-busy'); }
  }
  function updateSaved() {
    $$('[data-save]').forEach(button => { const active = saved.has(button.dataset.save); button.classList.toggle('active', active); button.setAttribute('aria-pressed', String(active)); const icon = $('i', button); if (icon) icon.className = active ? 'fas fa-heart' : 'far fa-heart'; });
    if ($('#wishlist-badge')) $('#wishlist-badge').textContent = saved.size;
  }
  function filter(category) {
    const cards = $$('.product-card[data-handle]'); let count = 0;
    cards.forEach(card => { const show = category === 'all' || (category === 'saved' ? saved.has(card.dataset.handle) : card.dataset.category === category || card.dataset.categories.split(/\s+/).includes(category)); card.hidden = !show; if (show) count++; });
    $$('.filter-btn').forEach(button => { const active = button.dataset.filter === category; button.classList.toggle('active', active); button.setAttribute('aria-pressed', String(active)); });
    if ($('#sg-filter-empty')) $('#sg-filter-empty').hidden = count > 0;
    if ($('#sg-status')) $('#sg-status').textContent = `${count} products shown.`;
  }
  function quickVariant() {
    const variant = quickProduct?.variants.find(v => String(v.id) === $('#sg-qv-select')?.value);
    const button = $('#qv-add-btn'); if (!button || !variant) return;
    button.disabled = !variant.available; button.querySelector('span').textContent = variant.available ? 'Add to Shopping Bag' : 'Sold out';
    $('#qv-price').textContent = money(variant.price);
    const src = variant.featured_image?.src || quickProduct.featured_image;
    if (src) { $('#sg-qv-image').src = src; $('#sg-qv-image').alt = quickProduct.title; $('#sg-qv-image').hidden = false; $('#qv-icon').hidden = true; }
  }
  async function quickView(url, button) {
    button.setAttribute('aria-busy', 'true');
    try {
      quickProduct = await json(`${url.split('?')[0]}.js`); quickTrigger = button;
      // Subscription apps need their product page to collect a valid plan.
      if (quickProduct.requires_selling_plan) { location.assign(url); return; }
      $('#qv-title').textContent = quickProduct.title; $('#qv-desc').textContent = '';
      $('#sg-qv-error').hidden = true; $('#sg-qv-image').hidden = true; $('#qv-icon').hidden = false;
      $('#sg-qv-details').href = url;
      const host = $('#sg-qv-variants'); host.replaceChildren();
      const label = document.createElement('label'); label.htmlFor = 'sg-qv-select'; label.textContent = 'Select options';
      const select = document.createElement('select'); select.id = 'sg-qv-select'; select.className = 'sg-qv-select';
      quickProduct.variants.forEach(variant => { const option = document.createElement('option'); option.value = variant.id; option.textContent = `${variant.title} — ${money(variant.price)}${variant.available ? '' : ' — Sold out'}`; option.disabled = !variant.available; select.append(option); });
      const available = quickProduct.variants.find(v => v.available); if (available) select.value = available.id;
      host.append(label, select); quickVariant(); openModal('quick-view-modal', button);
    } catch (e) { message('Unable to load options. Open the product page to choose your size.'); }
    finally { button.removeAttribute('aria-busy'); }
  }
  async function search(term) {
    searchAbort?.abort(); const q = term.trim(); const results = $('#search-results-preview');
    results.replaceChildren(); results.classList.toggle('show', !!q); if (!q) return;
    const loading = document.createElement('p'); loading.textContent = 'Searching…'; results.append(loading);
    searchAbort = new AbortController();
    try {
      const data = await json(`${config.predictive}.json?q=${encodeURIComponent(q)}&resources[type]=product&resources[limit]=6`, { signal: searchAbort.signal });
      results.replaceChildren();
      const products = data.resources?.results?.products || [];
      products.forEach(product => { const a = document.createElement('a'); a.className = 'search-result-item'; a.href = product.url; a.textContent = product.title; results.append(a); });
      const all = document.createElement('a'); all.className = 'search-result-item'; all.href = `${config.search}?q=${encodeURIComponent(q)}&type=product`; all.textContent = products.length ? 'View all results →' : 'Search the full catalog →'; results.append(all);
    } catch (e) { if (e.name !== 'AbortError') { results.replaceChildren(); const a = document.createElement('a'); a.href = `${config.search}?q=${encodeURIComponent(q)}&type=product`; a.textContent = 'View search results →'; results.append(a); } }
  }
  document.addEventListener('submit', event => {
    const form = event.target.closest('.sg-product-form'); if (!form) return;
    event.preventDefault(); if (form.reportValidity()) add(form, event.submitter || $('button[type="submit"]', form));
  });
  document.addEventListener('change', event => {
    if (event.target.id === 'sg-qv-select') quickVariant();
    if (event.target.matches('[data-variant-select]')) {
      const option = event.target.selectedOptions[0], form = event.target.form;
      const button = $('button[type="submit"]', form); button.disabled = option.dataset.available !== 'true'; button.textContent = button.disabled ? 'Sold out' : 'Add to Shopping Bag';
      const quantity = $('[name="quantity"]', form); quantity.min = option.dataset.min || 1; quantity.step = option.dataset.step || 1; quantity.value = quantity.min;
      if (option.dataset.max) quantity.max = option.dataset.max; else quantity.removeAttribute('max');
      $('[data-product-price]').textContent = option.dataset.price;
      const url = new URL(location.href); url.searchParams.set('variant', option.value); history.replaceState({}, '', url);
    }
  });
  document.addEventListener('click', async event => {
    const target = event.target.closest('button,a,[data-filter],.tag-pill'); if (!target) return;
    const openers = { 'mobile-menu-btn': 'mobile-drawer', 'search-open-btn': 'search-modal', 'cart-open-btn': 'cart-drawer', 'size-guide-nav-btn': 'size-guide-modal', 'size-guide-footer-btn': 'size-guide-modal', 'size-guide-mobile-btn': 'size-guide-modal' };
    const closers = ['mobile-drawer-close','search-close-btn','cart-close-btn','size-guide-close-btn','quick-view-close-btn'];
    if (openers[target.id] || target.matches('[data-open-size]')) { event.preventDefault(); openModal(openers[target.id] || 'size-guide-modal', target); if (target.id === 'cart-open-btn') refreshCart().catch(e => message(e.message,true)); return; }
    if (closers.includes(target.id)) { event.preventDefault(); closeModal(); return; }
    if (target.id === 'announcement-close-btn') $('#announcement-bar')?.classList.add('closed');
    if (target.id === 'mobile-products-toggle') { const expanded = $('#mobile-accordion')?.classList.toggle('open'); target.setAttribute('aria-expanded', String(expanded)); if ($('#mobile-chevron')) $('#mobile-chevron').style.transform = expanded ? 'rotate(180deg)' : 'rotate(0deg)'; }
    if (target.dataset.productUrl) { event.preventDefault(); quickView(target.dataset.productUrl, target); return; }
    if (target.id === 'qv-add-btn') {
      const variant = quickProduct?.variants.find(v => String(v.id) === $('#sg-qv-select')?.value); if (!variant?.available) return;
      const form = document.createElement('form'); form.innerHTML = '<input name="id"><input name="quantity"><button type="submit"></button><p class="sg-form-error"></p>'; $('[name="id"]',form).value = variant.id; $('[name="quantity"]',form).value = variant.quantity_rule?.min || 1;
      target.disabled = true; await add(form, quickTrigger); target.disabled = false;
      const error = $('.sg-form-error', form); if (error.textContent) { $('#sg-qv-error').textContent = error.textContent; $('#sg-qv-error').hidden = false; } return;
    }
    if (target.matches('[data-cart-delta],[data-cart-remove]')) {
      event.preventDefault(); const key = target.dataset.key;
      mutate(async () => {
        if (!cart) await refreshCart(); const item = cart.items.find(item => item.key === key); if (!item) return;
        const step = item.quantity_rule?.increment || 1; const min = item.quantity_rule?.min || 1;
        let quantity = target.hasAttribute('data-cart-remove') ? 0 : item.quantity + Number(target.dataset.cartDelta) * step;
        if (quantity < min) quantity = 0;
        const data = await json(endpoint(config.change), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: key, quantity, sections: ['sg-cart'], sections_url: location.pathname }) });
        await refreshCart(data.sections); message('Your bag has been updated.');
      }).catch(e => message(e.message,true)); return;
    }
    if (target.dataset.save) {
      const handle = target.dataset.save; saved.has(handle) ? saved.delete(handle) : saved.add(handle);
      try { localStorage.setItem(savedKey, JSON.stringify([...saved])); message(saved.has(handle) ? 'Saved on this device.' : 'Removed from saved items.'); } catch { message('Saved for this visit. Browser storage is unavailable.'); }
      updateSaved(); return;
    }
    if (target.id === 'wishlist-btn') { if ($('.product-card[data-handle]')) { filter('saved'); $('#product-grid')?.scrollIntoView({behavior:'smooth'}); message('Showing saved items in this selection.'); } else location.assign(config.root + '#new-arrivals'); return; }
    if (target.dataset.filter && $('#product-grid')) { event.preventDefault(); filter(target.dataset.filter); $('#new-arrivals')?.scrollIntoView({behavior:'smooth'}); closeModal(); }
    if (target.classList.contains('tag-pill')) { $('#search-input').value = target.textContent.trim(); search(target.textContent); }
    if (target.closest('#mobile-drawer') && target.tagName === 'A' && !target.id.includes('size-guide')) closeModal();
  });
  document.addEventListener('click', event => { if (modal && (event.target === modal || ['cart-drawer-overlay','mobile-drawer-overlay'].includes(event.target.id))) closeModal(); });
  document.addEventListener('keydown', event => {
    if (!modal) return;
    if (event.key === 'Escape') { event.preventDefault(); closeModal(); }
    if (event.key === 'Tab') { const nodes = focusables(modal); if (!nodes.length) { event.preventDefault(); return; } if (event.shiftKey && document.activeElement === nodes[0]) { event.preventDefault(); nodes.at(-1).focus(); } else if (!event.shiftKey && document.activeElement === nodes.at(-1)) { event.preventDefault(); nodes[0].focus(); } }
  });
  $('#search-input')?.addEventListener('input', event => { clearTimeout(searchTimer); searchTimer = setTimeout(() => search(event.target.value), 220); });
  window.addEventListener('storage', event => { if (event.key === savedKey) { try { const value = JSON.parse(event.newValue || '[]'); saved = new Set(Array.isArray(value) ? value : []); } catch { saved = new Set(); } updateSaved(); } });
  window.addEventListener('pageshow', event => { if (event.persisted) refreshCart().catch(() => {}); });
  document.addEventListener('shopify:section:load', updateSaved);
  function moveIndicator(item) { const indicator = $('#nav-indicator'); const link = $('.nav-link',item), nav = $('#desktop-nav'); if (indicator && link && nav) { indicator.style.width = `${link.offsetWidth}px`; indicator.style.left = `${link.getBoundingClientRect().left - nav.getBoundingClientRect().left}px`; } }
  $$('.nav-pill .nav-item').forEach(item => item.addEventListener('mouseenter', () => moveIndicator(item)));
  $('#desktop-nav')?.addEventListener('mouseleave', () => { const active = $('.nav-item.active'); if (active) moveIndicator(active); });
  window.addEventListener('resize', () => { const active = $('.nav-item.active'); if (active) moveIndicator(active); });
  window.addEventListener('scroll', () => $('#header-wrapper')?.classList.toggle('scrolled', scrollY > 50), {passive:true});
  document.fonts.ready.then(() => { const active = $('.nav-item.active'); if (active) moveIndicator(active); });
  for (const el of $$('#size-guide-modal,#quick-view-modal,#search-modal,#cart-drawer,#mobile-drawer')) { el.setAttribute('aria-hidden','true'); el.inert = true; }
  updateSaved();
  window.SGStore = { refreshCart, openCart: () => openModal('cart-drawer'), close: closeModal };
})();
